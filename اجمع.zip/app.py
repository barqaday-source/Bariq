from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

# كلمة السر الخاصة بك للتحكم (احفظها جيداً)
API_PASSWORD = "EBQAD_SECURE_2026" 

def get_db():
    conn = sqlite3.connect('ebqad_system.db')
    return conn

def init_db():
    with get_db() as conn:
        # 1. جدول المشاريع
        conn.execute('CREATE TABLE IF NOT EXISTS projects (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, image_url TEXT, tech_stack TEXT)')
        # 2. جدول الرسائل
        conn.execute('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, message TEXT, date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
        # 3. جدول معلومات "عني"
        conn.execute('CREATE TABLE IF NOT EXISTS about (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)')
        # 4. جدول المسؤولين (للتوثيق المستقبلي)
        conn.execute('CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)')
        
        # إضافة نص افتراضي إذا كان جدول "عني" فارغاً
        if not conn.execute('SELECT * FROM about').fetchone():
            conn.execute('INSERT INTO about (content) VALUES ("Innovation Driven by Aquarius Intelligence")')

def check_auth():
    auth_key = request.headers.get('X-API-KEY')
    return auth_key == API_PASSWORD

@app.route('/api/projects', methods=['GET', 'POST'])
def projects():
    conn = get_db()
    if request.method == 'POST':
        if not check_auth(): return jsonify({"error": "Unauthorized"}), 401
        d = request.json
        conn.execute('INSERT INTO projects (title, description, image_url, tech_stack) VALUES (?,?,?,?)', 
                     (d['title'], d['description'], d['image_url'], d['tech_stack']))
        conn.commit()
    res = conn.execute('SELECT * FROM projects').fetchall()
    return jsonify([{"id":r[0],"title":r[1],"description":r[2],"image_url":r[3],"tech_stack":r[4]} for r in res])

@app.route('/api/projects/<int:id>', methods=['DELETE'])
def delete_project(id):
    if not check_auth(): return jsonify({"error": "Unauthorized"}), 401
    conn = get_db()
    conn.execute('DELETE FROM projects WHERE id=?', (id,))
    conn.commit()
    return jsonify({"status":"deleted"})

@app.route('/api/messages', methods=['GET', 'POST'])
def messages():
    conn = get_db()
    if request.method == 'POST':
        d = request.json
        conn.execute('INSERT INTO messages (name, email, message) VALUES (?,?,?)', (d['name'], d['email'], d['message']))
        conn.commit()
        return jsonify({"status":"sent"})
    if not check_auth(): return jsonify({"error": "Unauthorized"}), 401
    res = conn.execute('SELECT * FROM messages').fetchall()
    return jsonify([{"id":r[0],"name":r[1],"email":r[2],"message":r[3],"date":r[4]} for r in res])

@app.route('/api/about', methods=['GET', 'POST'])
def about():
    conn = get_db()
    if request.method == 'POST':
        if not check_auth(): return jsonify({"error": "Unauthorized"}), 401
        conn.execute('UPDATE about SET content=? WHERE id=1', (request.json['content'],))
        conn.commit()
    res = conn.execute('SELECT content FROM about WHERE id=1').fetchone()
    return jsonify({"content": res[0] if res else ""})

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000)
